var express = require('express');
var app = express();
var mysql = require('mysql');
var bodyparser = require("body-parser");  
var mongo = require('mongodb');
//var mongoClient = mongo.mongoClient;
var url = "mongodb://localhost:27017/crud";

app.use(bodyparser.urlencoded({ extended: false }));

con=mongo.connect(url,(err,res)=>{
    if(err){
        console.log('server not connected: '+err);
    }
    else{
        console.log('Connected '+res);
    }
});

// var con = mysql.createConnection({
//     host:'localhost',
//     user:'root',
//     password:'12345',
//     database:'crud'
// });
// console.log(con)
// module.exports = con;

app.set('view engine','ejs')
app.set('views','./views')


app.use(require('./routes/base'));
app.use(require('./routes/add'));
app.use(require('./routes/edit'));
app.use(require('./routes/delete'));


app.listen(3000,()=>console.log('listen at port 3000'));