var express = require('express');
var route = express.Router();
var con = require('../index');

route.get('/edit',(req,res)=>{
    // user_data = req.query;
    // console.log(user_data.name)
    // con.query(`update data set name="${user_data.name}",age=${user_data.age},dob="${user_data.dob}" where id=${user_data.id}`)
    res.redirect('/');
});

module.exports = route;