var express = require('express');
var route = express.Router();
var con = require('../index');
var bodyparser = require("body-parser");  

route.use(bodyparser.urlencoded({ extended: false }));

console.log('this is '+con);

route.get('/',(req,res)=>{
        
//     con.query('select * from data',(err,result)=>{
//         if(err){
//             throw err;
//         }
//         else{
//             for(row of result){
//             console.log(row.name);
//             }
            res.render('index');//,{data:result});
    //     }
    // });
});

module.exports = route;