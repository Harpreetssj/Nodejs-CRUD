var express = require('express');
var route = express.Router();
var con = require('../index');

route.get('/delete',(req,res)=>{
    // console.log(req.params);
    // console.log(req.query.id);
    // qry=`delete from data where id=${req.query.id}`
    // con.query(qry,(err,result)=>{
    //     if(err){
    //         throw err;
    //     }
    //     else{
            res.redirect("/");
    //     }
    // });
});

module.exports = route;