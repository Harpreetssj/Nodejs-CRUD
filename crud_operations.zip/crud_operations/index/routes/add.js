var express = require('express');
var route = express.Router();
// var con = require('../index');

route.post('/add',(req,res)=>{
    user_add=req.body;
    // qry=`insert into data values(${user_add.id},"${user_add.name}",${user_add.age},"${user_add.dob}")`;
    // console.log(qry);
    // con.query(qry,(err,result)=>{
    //     if(err){
    //         throw err;
    //     }
    //     else{
            res.redirect("/");
    //     }
    // })
});

module.exports = route;